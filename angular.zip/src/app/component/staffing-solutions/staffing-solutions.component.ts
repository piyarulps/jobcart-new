import { Component } from '@angular/core';

@Component({
  selector: 'app-staffing-solutions',
  templateUrl: './staffing-solutions.component.html',
  styleUrl: './staffing-solutions.component.scss'
})
export class StaffingSolutionsComponent {

}
