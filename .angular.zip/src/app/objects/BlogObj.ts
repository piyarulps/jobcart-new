export class BlogObj{
    blogId!: number;
    usrId!: number;    
    blogUrl!: string;
    blogTitle!: string;
    blogSummary!: string;
    blogDescp!: string;
    blogImgFP!: string;
    imgCaption!: string;
    blogImg!: string;
    blogImgFullPath!: string;
    createdDt!: string;
    blogStatus!: string;
    blogSeq!: number;
    pageTitle!: string;
    pageKeywords!: string;
    pageDescp!: string;
    constructor() {   }
}