export class CatObj{
    catId!: number;
    activeJobs!: number;
    catTitle!: string;
    catDescp!: string;
    catImg!: string;
    status!: string;
    seq!: string;
    constructor() {   }
}