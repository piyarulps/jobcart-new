export const environment = {
  production: true,

  app_url     : "https://app.jobcart.ca/",
  api_url     : 'https://apis.jobcart.ca/',
  assets_url  : "https://jcassets.jobcart.ca/",
  pdf_url     : 'https://pdf.jobcart.ca',
  envToken    : "8vT6YG1y5NZa2mED8VSr22020207430525",

  jwt_api     : 'auth-api/',
  auth_api    : 'account-api/',
  acc_api     : 'account-api/',
  global_api  : 'glb-api/',
  post_api    : 'post-api/',
  blog_api    : 'blog-api/',
  
  
};